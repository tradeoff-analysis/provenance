The “ProvenanceAnalysisNotebook.ipynb” file is a Jupyter notebook file. 
To access its contents, you may need to install Jupyter notebook as well as python 3.7 on your machine.
An easy way to do that is to install Anaconda (https://docs.anaconda.com/anaconda/install/)